package QuestionA;

import java.util.Date;
 
public interface iPersonRead {

	String getFirstName(String FirstName);
	
	 String getMiddleName(String MidleName);
	
	String getLastName(String LastName);
	
	 Date getDOB(Date DOB);
	
	String getAddress(String Address); 

	String getPhone(String Phone);
	
	 String getEmail(String Email);
}
