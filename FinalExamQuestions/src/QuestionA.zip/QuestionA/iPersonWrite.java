package QuestionA;

import java.util.Date;
import QuestionA.Person;

public interface iPersonWrite {

	public void setFirstName(String FirstName);
	
	public void setMiddleName(String MiddleName);
	
	public void setLastName(String LastName);

	public void setDOB(Date DOB);
	
	public void setAddress(String newAddress);
	
	public void setPhone(String newPhone_number);
	
	public void setEmail(String newEmail);
}
